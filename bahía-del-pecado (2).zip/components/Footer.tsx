import React from 'react';
import { GlobeIcon, InstagramIcon, TikTokIcon } from './icons/Icons';

const SocialIcon: React.FC<{ href: string; children: React.ReactNode }> = ({ href, children }) => (
    <a href={href} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-amber-400 transition-colors duration-300">
        {children}
    </a>
);

const Footer: React.FC = () => {
    return (
        <footer className="bg-black py-8">
            <div className="container mx-auto px-6 text-center text-gray-500">
                <div className="flex justify-center space-x-6 mb-4">
                    <SocialIcon href="http://www.bahiadelpecado.com">
                        <GlobeIcon className="h-6 w-6" />
                    </SocialIcon>
                    <SocialIcon href="https://www.instagram.com/BahiaDelPecadoGame">
                       <InstagramIcon className="h-6 w-6" />
                    </SocialIcon>
                     <SocialIcon href="https://www.tiktok.com/@BahiaDelPecado">
                        <TikTokIcon className="h-6 w-6" />
                    </SocialIcon>
                </div>
                <p className='text-sm mb-2'>Sigue las actualizaciones en www.bahiadelpecado.com</p>
                <p className="text-sm">&copy; {new Date().getFullYear()} Bahía del Pecado. Un proyecto conceptual. Todos los derechos reservados.</p>
            </div>
        </footer>
    );
};

export default Footer;