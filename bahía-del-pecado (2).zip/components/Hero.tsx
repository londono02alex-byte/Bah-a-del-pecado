import React from 'react';

const Hero: React.FC = () => {
    const scrollToFeatures = () => {
        document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' });
    };

    return (
        <section 
            id="home"
            className="h-screen w-full flex items-center justify-center text-center text-white relative overflow-hidden"
        >
            <video
                autoPlay
                muted
                loop
                playsInline
                className="absolute top-0 left-0 w-full h-full object-cover z-0"
                src="https://storage.googleapis.com/gemini-prod-us-central1-gd_prototyping_assets/bahia_del_pecado_hero_intro.mp4"
            />
            <div className="absolute inset-0 bg-black bg-opacity-60"></div>
            <div className="relative z-10 p-4">
                <h1 className="text-5xl md:text-7xl lg:text-8xl font-black uppercase tracking-widest fade-in-1" style={{ fontFamily: "'Playfair Display', serif" }}>
                    Bahía del Pecado
                </h1>
                <p className="text-xl md:text-2xl lg:text-3xl font-light mt-4 tracking-wide italic fade-in-2">
                    “El que manda no se anuncia, se siente.”
                </p>
                <p className="mt-8 max-w-2xl mx-auto text-gray-300 text-base md:text-lg fade-in-3">
                    Sumérgete en un mundo abierto hiperrealista en 4K. Eres Alex Vega, un renegado que busca venganza y control en las calles corruptas de Cartagena.
                </p>
                <button 
                    onClick={scrollToFeatures}
                    className="mt-12 px-8 py-4 bg-amber-500 text-black font-bold rounded-full text-lg hover:bg-amber-400 transition-all duration-300 hover:scale-105 shadow-lg shadow-amber-500/50 hover:shadow-amber-400/80 fade-in-4">
                    Explora la Bahía
                </button>
            </div>
            <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                </svg>
            </div>
        </section>
    );
};

export default Hero;