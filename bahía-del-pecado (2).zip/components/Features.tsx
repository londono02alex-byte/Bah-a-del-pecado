import React from 'react';
import { FortressIcon, SkyscraperIcon, CommunityIcon, IslandIcon } from './icons/Icons';

interface Feature {
    icon: React.ElementType;
    title: string;
    description: string;
}

const features: Feature[] = [
    {
        icon: SkyscraperIcon,
        title: "El Malecón",
        description: "Epicentro de fiestas, carreras clandestinas y negocios ilegales que nunca duermen bajo las luces de neón."
    },
    {
        icon: CommunityIcon,
        title: "Getsecrash",
        description: "Barrio artístico y vibrante, donde los grafitis, las armas y los hackers escriben las nuevas reglas del juego."
    },
    {
        icon: FortressIcon,
        title: "La Muralla Vieja",
        description: "Territorio sagrado controlado por las mafias tradicionales y los políticos más corruptos de la ciudad."
    },
    {
        icon: IslandIcon,
        title: "La Zona Cero",
        description: "El puerto industrial donde empezó todo. Un laberinto de contenedores, grúas y oscuros secretos."
    }
];

const FeatureCard: React.FC<Feature> = ({ icon: Icon, title, description }) => (
    <div className="bg-[#1e1e1e] p-8 rounded-lg shadow-lg text-center transform hover:-translate-y-2 transition-transform duration-300">
        <div className="mx-auto bg-amber-500 rounded-full h-16 w-16 flex items-center justify-center mb-6">
            <Icon className="h-8 w-8 text-black" />
        </div>
        <h3 className="text-2xl font-bold text-white mb-3">{title}</h3>
        <p className="text-gray-400">{description}</p>
    </div>
);


const Features: React.FC = () => {
    return (
        <section id="features" className="py-20 md:py-28 bg-[#181818]">
            <div className="container mx-auto px-6">
                <div className="text-center mb-16">
                    <h2 className="text-4xl md:text-5xl font-bold text-white">EL MUNDO</h2>
                    <p className="text-lg text-gray-400 mt-4 max-w-3xl mx-auto">
                        Bahía del Pecado es una ciudad ficticia inspirada en Cartagena de Indias. Entre sus murallas y rascacielos se libra una guerra silenciosa por el control. Un paraíso de día, un campo de batalla de noche.
                    </p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                    {features.map((feature, index) => (
                        <FeatureCard key={index} {...feature} />
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Features;