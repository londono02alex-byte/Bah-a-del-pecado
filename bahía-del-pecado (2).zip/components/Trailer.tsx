import React from 'react';

const scriptSections = [
    {
        scene: "Cita de Apertura",
        dialogue: "Dicen que en Cartagena el sol brilla para todos… pero en la calle… no todos viven para contarlo."
    },
    {
        scene: "Voz en Off",
        dialogue: "El que manda no se anuncia… se siente."
    },
    {
        scene: "Montaje de Acción",
        dialogue: "Cámaras lentas, el reflejo del fuego, persecuciones y el reguetón marcando el pulso de una ciudad que respira peligro."
    },
    {
        scene: "Declaración Final",
        dialogue: "Bienvenido a la Bahía del Pecado… donde la lealtad se paga con sangre."
    }
];

const Trailer: React.FC = () => {
    return (
        <section id="trailer" className="py-20 md:py-28 bg-[#181818]">
            <div className="container mx-auto px-6">
                <div className="text-center mb-16">
                    <h2 className="text-4xl md:text-5xl font-bold text-white">TRÁILER</h2>
                    <p className="text-lg text-gray-400 mt-4 max-w-3xl mx-auto italic">
                        Música: reguetón oscuro, bajo profundo, percusión caribeña y toques de trap latino.
                    </p>
                </div>
                <div className="grid lg:grid-cols-2 gap-12 items-start">
                    {/* Video Player */}
                    <div className="rounded-lg shadow-2xl overflow-hidden aspect-video bg-black">
                        <video
                            controls
                            preload="metadata"
                            className="w-full h-full"
                            poster="https://storage.googleapis.com/gemini-prod-us-central1-gd_prototyping_assets/735c0571-d85c-4235-8f67-0b1a851e39a5"
                        >
                            <source src="https://storage.googleapis.com/gemini-prod-us-central1-gd_prototyping_assets/bahia_del_pecado_trailer_final_mix.mp4" type="video/mp4" />
                            Tu navegador no soporta el elemento de vídeo.
                        </video>
                    </div>
                    {/* Script */}
                    <div className="bg-[#1e1e1e] p-6 rounded-lg">
                         <h3 className="text-2xl font-bold text-white mb-4 border-b border-gray-700 pb-2">Guion de Voz</h3>
                         <div className="space-y-6 max-h-[500px] overflow-y-auto pr-4">
                            {scriptSections.map((section, index) => (
                                <div key={index}>
                                    <p className="text-amber-400 font-bold text-sm tracking-widest uppercase">{section.scene}</p>
                                    <blockquote className="border-l-4 border-amber-500 pl-4 text-gray-300 text-lg leading-relaxed mt-2">
                                        <p>{`“${section.dialogue}”`}</p>
                                    </blockquote>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Trailer;