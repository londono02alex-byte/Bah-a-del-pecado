import React, { useState, useEffect } from 'react';

const Header: React.FC = () => {
    const [scrolled, setScrolled] = useState(false);

    useEffect(() => {
        const handleScroll = () => {
            const isScrolled = window.scrollY > 10;
            if (isScrolled !== scrolled) {
                setScrolled(isScrolled);
            }
        };

        document.addEventListener('scroll', handleScroll);
        return () => {
            document.removeEventListener('scroll', handleScroll);
        };
    }, [scrolled]);

    return (
        <header className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${scrolled ? 'bg-black bg-opacity-80 backdrop-blur-sm shadow-lg' : 'bg-transparent'}`}>
            <div className="container mx-auto px-6 py-4 flex justify-between items-center">
                <a href="#home" className="text-2xl md:text-3xl font-bold text-white tracking-wider" style={{ fontFamily: "'Playfair Display', serif" }}>
                    Bahía del Pecado
                </a>
                <nav className="hidden md:flex space-x-8">
                    <a href="#features" className="text-gray-300 hover:text-amber-400 transition-colors duration-300">El Mundo</a>
                    <a href="#trailer" className="text-gray-300 hover:text-amber-400 transition-colors duration-300">Tráiler</a>
                    <a href="#gameplay" className="text-gray-300 hover:text-amber-400 transition-colors duration-300">El Juego</a>
                    <a href="#arte" className="text-gray-300 hover:text-amber-400 transition-colors duration-300">Arte</a>
                    <a href="#noticias" className="text-gray-300 hover:text-amber-400 transition-colors duration-300">Noticias</a>
                </nav>
            </div>
        </header>
    );
};

export default Header;