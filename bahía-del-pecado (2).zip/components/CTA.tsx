import React from 'react';
import { GoogleIcon, FacebookIcon, TwitterIcon, MailIcon } from './icons/Icons';

interface NewsItemProps {
    title: string;
    content?: string;
    children?: React.ReactNode;
}

const NewsItem: React.FC<NewsItemProps> = ({ title, content, children }) => (
    <div className="bg-[#1e1e1e] p-6 rounded-lg text-left h-full">
        <h3 className="text-xl font-bold text-amber-400">{title}</h3>
        {content && <p className="text-gray-300 mt-2">{content}</p>}
        {children}
    </div>
);


const CTA: React.FC = () => {
    return (
        <section id="noticias" className="py-20 md:py-28 bg-[#181818]">
            <div className="container mx-auto px-6 text-center">
                <h2 className="text-4xl md:text-5xl font-bold text-white mb-16">NOTICIAS</h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto mb-20">
                    <NewsItem title="📢 Lanzamiento Oficial" content="Próximamente disponible en Android (APK), PC y versión WebGL. La Bahía te espera." />
                    <NewsItem title="🎶 Banda Sonora" content="Reguetón, trap y sonidos callejeros producidos en colaboración con artistas emergentes del Caribe y Medellín." />
                    <NewsItem title="🎤 Voces Oficiales" content="Narración cinematográfica con acento costeño. Locuciones grabadas para una inmersión total en el ambiente tropical-urbano." />
                    <NewsItem title="💥 Próximos Anuncios">
                        <ul className="list-disc list-inside text-gray-300 mt-2 space-y-1">
                            <li>Beta jugable: “La Bahía Sangrienta”</li>
                            <li>Tráiler 2: “El Retorno de Alex Vega”</li>
                            <li>Arte conceptual y detrás de cámaras.</li>
                        </ul>
                    </NewsItem>
                </div>
                
                <h3 className="text-3xl md:text-4xl font-bold text-white">Domina la Bahía</h3>
                <p className="text-md md:text-lg text-gray-400 mt-4 max-w-2xl mx-auto">
                    La lealtad tiene sus recompensas. Elige tu bando y regístrate para asegurar tu lugar, recibir acceso anticipado y contenido exclusivo.
                </p>
                <div className="mt-12 max-w-lg mx-auto">
                    <div className="flex flex-col space-y-4">
                        <button
                            type="button"
                            className="w-full flex items-center justify-center px-6 py-3 bg-white text-gray-800 font-bold rounded-full text-lg hover:bg-gray-200 transition-colors duration-300 shadow-md"
                        >
                            <GoogleIcon className="h-6 w-6 mr-3" />
                            Continuar con Google
                        </button>
                        <button
                            type="button"
                            className="w-full flex items-center justify-center px-6 py-3 bg-[#1877F2] text-white font-bold rounded-full text-lg hover:bg-[#166eeb] transition-colors duration-300 shadow-md"
                        >
                            <FacebookIcon className="h-6 w-6 mr-3" />
                            Continuar con Facebook
                        </button>
                        <button
                            type="button"
                            className="w-full flex items-center justify-center px-6 py-3 bg-black text-white font-bold rounded-full text-lg hover:bg-gray-800 transition-colors duration-300 border border-gray-600 shadow-md"
                        >
                            <TwitterIcon className="h-6 w-6 mr-3" />
                            Continuar con X
                        </button>
                    </div>

                    <div className="my-6 flex items-center">
                        <div className="flex-grow border-t border-gray-600"></div>
                        <span className="flex-shrink mx-4 text-gray-400">O</span>
                        <div className="flex-grow border-t border-gray-600"></div>
                    </div>
                    
                    <button
                        type="button"
                        className="w-full flex items-center justify-center px-6 py-3 bg-amber-500 text-black font-bold rounded-full text-lg hover:bg-amber-400 transition-colors duration-300 shadow-lg shadow-amber-500/30"
                    >
                        <MailIcon className="h-6 w-6 mr-3" />
                        Registrarse con correo
                    </button>
                    <p className="text-xs text-gray-500 mt-8">
                        Al registrarte, aceptas nuestros Términos de Servicio y Política de Privacidad.
                    </p>
                </div>
            </div>
        </section>
    );
};

export default CTA;