import React from 'react';

const images = [
    { src: 'https://storage.googleapis.com/gemini-prod-us-central1-gd_prototyping_assets/e242944a-9b7e-4fe1-8e01-08103387d37a', alt: 'Póster oficial de Bahía del Pecado con Alex Vega.' },
    { src: 'https://storage.googleapis.com/gemini-prod-us-central1-gd_prototyping_assets/12a8433d-730c-4148-8422-953e5e435987', alt: 'Coche deportivo de lujo en las calles de Cartagena.' },
    { src: 'https://storage.googleapis.com/gemini-prod-us-central1-gd_prototyping_assets/1879714e-e478-4309-8d76-1cb7d5b12879', alt: 'Callejón oscuro en el Centro Histórico.' },
    { src: 'https://storage.googleapis.com/gemini-prod-us-central1-gd_prototyping_assets/e53a2f7c-5015-46f3-a745-b44c2d4a2069', alt: 'Motocicleta MT09 dorada lista para la acción.' },
    { src: 'https://storage.googleapis.com/gemini-prod-us-central1-gd_prototyping_assets/3e527f52-5a9e-4a6c-9457-37151e39755b', alt: 'Una lujosa mansión en las islas.' },
    { src: 'https://storage.googleapis.com/gemini-prod-us-central1-gd_prototyping_assets/735c0571-d85c-4235-8f67-0b1a851e39a5', alt: 'El horizonte de Bocagrande al anochecer.' },
];

const Gallery: React.FC = () => {
    return (
        <section id="arte" className="py-20 md:py-28 bg-[#121212]">
            <div className="container mx-auto px-6">
                <div className="text-center mb-16">
                    <h2 className="text-4xl md:text-5xl font-bold text-white">ARTE</h2>
                    <p className="text-lg text-gray-400 mt-4 max-w-3xl mx-auto">
                        Una mezcla de lo tropical con lo tecnológico: colores cálidos, luces de neón y grafitis futuristas. Un estilo Cyberpunk latino donde el poder, el ritmo y el peligro se sienten en cada detalle.
                    </p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {images.map((image, index) => (
                        <div key={index} className="overflow-hidden rounded-lg shadow-xl group h-96">
                            <img 
                                src={image.src} 
                                alt={image.alt} 
                                className="w-full h-full object-cover object-center transform group-hover:scale-110 transition-transform duration-500 ease-in-out" 
                            />
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Gallery;