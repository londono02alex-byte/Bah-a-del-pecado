import React from 'react';
import { StoryIcon, CompassIcon, FistIcon } from './icons/Icons';

interface GameplayPillar {
    icon: React.ElementType;
    title: string;
    description: string;
}

const pillars: GameplayPillar[] = [
    {
        icon: CompassIcon,
        title: "Libertad y Exploración",
        description: "Conduce, dispara, escala y explora en un entorno vivo. La ciudad es tuya para dominarla."
    },
    {
        icon: StoryIcon,
        title: "Sistema de Reputación",
        description: "Cada decisión que tomas cambia el rumbo de tu historia. Gánate el respeto a fuego y sangre."
    },
    {
        icon: FistIcon,
        title: "Acción y Personalización",
        description: "Personaliza tus autos, ropa, tatuajes y armas para convertirte en una leyenda de la Bahía."
    }
];

const Pillar: React.FC<GameplayPillar> = ({ icon: Icon, title, description }) => (
    <li className="flex items-start space-x-4">
        <div className="flex-shrink-0">
            <Icon className="h-8 w-8 text-amber-400" />
        </div>
        <div>
            <h4 className="text-xl font-bold text-white">{title}</h4>
            <p className="text-gray-400 mt-1">{description}</p>
        </div>
    </li>
);

const Gameplay: React.FC = () => {
    return (
        <section id="gameplay" className="py-20 md:py-28 bg-[#121212]">
            <div className="container mx-auto px-6">
                <div className="grid md:grid-cols-2 gap-12 items-center">
                    <div className="order-2 md:order-1">
                        <h2 className="text-4xl md:text-5xl font-bold text-white">EL JUEGO</h2>
                        <p className="text-lg text-gray-400 mt-6">
                            Un mundo abierto urbano en 4K. Conduce, dispara, hackea y negocia para tomar el control de la Bahía. Tu objetivo es claro: <strong>descubrir quién traicionó a tu familia y reclamar tu trono.</strong>
                        </p>
                        <ul className="mt-8 space-y-6">
                            {pillars.map((pillar) => (
                                <Pillar key={pillar.title} {...pillar} />
                            ))}
                        </ul>
                    </div>
                    <div className="order-1 md:order-2">
                        <img 
                            src="https://storage.googleapis.com/gemini-prod-us-central1-gd_prototyping_assets/e242944a-9b7e-4fe1-8e01-08103387d37a" 
                            alt="Alex Vega (JAL), protagonista de Bahía del Pecado, en Cartagena" 
                            className="rounded-lg shadow-2xl w-full h-full object-cover"
                        />
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Gameplay;